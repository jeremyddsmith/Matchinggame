enum AppRoute {
  home,
  game,
}

